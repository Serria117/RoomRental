/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.model.dao;

import com.model.Room;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoomDAO {

    public static Database db = new Database();

    public List<Room> getAll(boolean allRoom) {
        List<Room> roomList;
        Connection conn = null;
        ResultSet rs = null;
        PreparedStatement stm = null;
        try {
            conn = db.conn();
            String query = allRoom == true ? "SELECT * FROM ROOM" : "SELECT * FROM ROOM WHERE STATUS = 1";
            stm = conn.prepareStatement(query);
            rs = stm.executeQuery();
            roomList = new ArrayList<>();
            while (rs.next()) {
                Room room = new Room(
                        rs.getInt("id"),
                        rs.getString("roomNumber"),
                        rs.getInt("price"),
                        rs.getInt("square"),
                        rs.getString("description"),
                        rs.getInt("status"),
                        rs.getInt("electricCounter"),
                        rs.getInt("waterCounter")
                );
                roomList.add(room);
            }
            return roomList;
        } catch (SQLException e) {
            return null;
        } finally {
            db.closeAll(conn, stm, rs);
        }
    }

//    public List<Room> searchRooms(String key) {
//
//    }
    public Room getRoom(int id) {
        Room room = new Room();

        return room;
    }

    public boolean addRoom() {
        boolean status = false;

        return status;
    }

    public boolean updateRoom(int id) {
        boolean status = false;

        return status;

    }

    //test:
    public static void main(String[] args) {
        RoomDAO room = new RoomDAO();
        List<Room> list = room.getAll(true);
        list.stream().forEach(r -> System.out.println(r.toString()));
    }

}
