/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.model;

import java.sql.Date;

/**
 *
 * @author hadt2
 */
public class Guest {

    private int id;
    private String fullName;
    private String phone;
    private String pin;
    private Date birthDate;
    private int status;

    @Override
    public String toString() {
        return "Guest{" + "id=" + id + ", fullName=" + fullName + ", phone=" + phone + ", pin=" + pin + ", birthDate=" + birthDate + ", status=" + status + '}';
    }

    public Guest() {
    }

    public Guest(int id, String fullName, String phone, String pin, Date birthDate, int status) {
        this.id = id;
        this.fullName = fullName;
        this.phone = phone;
        this.pin = pin;
        this.birthDate = birthDate;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

}
